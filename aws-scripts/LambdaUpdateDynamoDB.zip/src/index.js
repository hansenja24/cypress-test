const LOG4JS = require('log4js');
let logger = LOG4JS.getLogger('NemoSiteScraper Lambda');
logger.level = 'debug';

const async = require('async');

const request = require('request');

const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();

//Lambda Handler
exports.handler = function (event, context, callback) {
    // https://8cr5vzgtq5.execute-api.us-west-2.amazonaws.com/prod?email=hansen2@hansen.com&productId=123&siteId=aml
    if (event == null) {
        context.fail('Nothing passed in!');
    } else {

        // let emailInput = event.body.email;
        let emailInput = "hanseja24";
        let params = {
            TableName: GithubId,
            Key: {
                emailinput: emailInput
            }
        };

        //Check if the product input number is already exist in database or not
        dynamodb.get(readParams, (err, data) => {
            if (err) {
                logger.error(`Error reading table dynamoDB: `, err);
            } else {

                let emailParams;
                if (Object.keys(data).length == 0) {
                    dynamodb.update(params, (err, data) => {
                        if (err) {
                            logger.error(`Error updating table DynamoDB: `, err)
                        } else {
                            logger.info(` ${emailInput} updated in DynamoDB table`);
                            context.succeed(data);
                        }
                    });
                }


            }
        });
      }
}
